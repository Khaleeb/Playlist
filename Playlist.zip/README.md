# Playlist
### CISC 260: Mini Project 2: Playlist
#####  *Caleb Davis*

### Screenshots:
![alt text](https://github.com/Khaleeb/Playlist/blob/main/brandnewlist.png "Brand New List")
![alt text](https://github.com/Khaleeb/Playlist/blob/main/removingsong.png "Removing Song")
![alt text](https://github.com/Khaleeb/Playlist/blob/main/shuffle.png "Shuffle")
### To Build:
```
make Playlist
./Playlist
```

### To Clean:
```
make clean
```
